export interface ICourse {
    _id: string;
    name: string;
    number: string;
    courseText: string;
    startDate: string;
    endDate: string;
    image: string;
}