export interface ILesson {
    _id: string;
    name: string;
    description: string;
    module: string;
    indent: number;
}