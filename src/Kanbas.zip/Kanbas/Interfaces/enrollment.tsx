export interface IEnrollment {
    _id: string;
    user: string;
    course: string;
}
